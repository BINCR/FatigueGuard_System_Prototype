import 'package:flutter/material.dart';
import 'package:hive_ce_flutter/hive_flutter.dart';

import 'login.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize local storage.
  await Hive.initFlutter();

  // Stores one record for every driving session.
  await Hive.openBox('driving_sessions');

  // Stores important fatigue and distraction events.
  await Hive.openBox('detection_events');

  runApp(const FatigueGuardApp());
}

class FatigueGuardApp extends StatelessWidget {
  const FatigueGuardApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FatigueGuard',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF3525CD),
      ),
      home: const LoginPage(),
    );
  }
}